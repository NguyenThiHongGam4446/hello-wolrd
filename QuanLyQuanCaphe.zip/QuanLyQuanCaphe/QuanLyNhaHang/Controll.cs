﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Data;

namespace QuanLyNhaHang
{
    
    public class Controll
    {
        string chuoiketnoi =
            System.Configuration.ConfigurationManager.ConnectionStrings["QLNH"].ConnectionString;

       

        public int checkDangNhap(string username, string pass)
        {
            SqlConnection con = new SqlConnection(chuoiketnoi);
            con.Open();
            string sql1 = "select count(*) from NHANVIEN where USER ='" + username + "' and PASS ='" + pass + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, con);
            int result1 = (int)cmd1.ExecuteScalar();
            if (result1 >= 1)
            {
                return 1; // la NHANVIEN
            }
            return 0;
        }
    }
}