﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Data;
namespace QuanLyNhaHang.DangNhap
{

    public partial class DangNhap : System.Web.UI.Page
    {
        string chuoiketnoi =
            System.Configuration.ConfigurationManager.ConnectionStrings["QLNH"].ConnectionString;
        Controll controll = new Controll();
        string username, pass;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDangNhap_Click(object sender, EventArgs e)
        { 
            string tk = txtTK.Text;
            string mk = txtMK.Text;
            if((tk.Equals("khanh") && mk.Equals("khanh"))|| (tk.Equals("nhien") && mk.Equals("nhien"))){
              
                Session["user"] = txtTK.Text;
                
                Response.Redirect("/TrangChu/trangchu.aspx");

            }
            else{
                thongbao.Text = "Tài khoản hoặc mật khẩu không đúng";
            }
            /*
            SqlConnection con = new SqlConnection(chuoiketnoi);
            con.Open();
            string da = "select * from NHANVIEN where USER ='" + txtTK.Text + "' and PASS ='" + txtMK.Text + "'";

            SqlDataAdapter cmd = new SqlDataAdapter(da, con);
            DataTable tb = new DataTable();
            cmd.Fill(tb);
            if (tb.Rows.Count < 0)
            {
                
            }

            else
            {
                thongbao.Text = "tài khoản hoặc mật khẩu không đúng";
            }*/
        }
    }
}
            /*SqlConnection con = new SqlConnection(chuoiketnoi);
        SqlDataAdapter da = new SqlDataAdapter("select * from NHANVIEN where USER='" + txtTK.Text + "' and PASS='" + txtMK.Text + "'", con);
        DataTable tb = new DataTable();
        da.Fill(tb);
        if (tb.Rows.Count > 0)
        {
            Response.Write("<script>alert('Đăng nhập thành công')</script>");
        }
        else Response.Write("<script>alert('Username/Password chưa đúng')</script>");
    }
        }*/
