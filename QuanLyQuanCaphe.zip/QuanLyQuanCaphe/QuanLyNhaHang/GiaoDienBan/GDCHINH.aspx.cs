﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Data;

namespace QuanLyNhaHang.GiaoDienBan
{
    public partial class GDCHINH : System.Web.UI.Page
    {
        string chuoiketnoi =
            System.Configuration.ConfigurationManager.ConnectionStrings["QLNH"].ConnectionString;
        Controll control = new Controll();
        //string makhu;

        protected void Page_Load(object sender, EventArgs e)

        {
            if(!IsPostBack)
            {
                
               
                if(Session["user"]==null)
                {
                    Response.Redirect("/DangNhap/DangNhap.aspx");
                }
                DataList2.Visible = false;
                //Response.Write("Đăng nhập thất bại");
                btnhere.Text = Session["user"].ToString();
            }
            
        }

        public int nhanvien(string tendangnhap)
        {
            string sql = "select HOTEN from NHANVIEN where USER='" + tendangnhap + "'";

            using (SqlConnection con = new SqlConnection(chuoiketnoi))
            {
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                int hoten = (int)cmd.ExecuteScalar();
                return hoten;
            }
        }
       
        protected void btnhere_Click(object sender, EventArgs e)
        {
            DataList1.Visible = true;
            DataList2.Visible = false; 
        }

        protected void btnMV_Click(object sender, EventArgs e)
        {
            DataList1.Visible = false;
            DataList2.Visible = true; 
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string id = (sender as Button).CommandArgument ;
            Response.Redirect("order.aspx?id=" +id);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string id = (sender as Button).CommandArgument ;
            Response.Redirect("order.aspx?id=" + id);
        }
    }
}