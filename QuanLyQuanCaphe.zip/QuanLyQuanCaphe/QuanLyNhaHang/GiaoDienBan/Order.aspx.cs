﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace QuanLyNhaHang.GiaoDienBan
{
    public partial class Order : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["QLNH"].ConnectionString;
        string name;
        int sl = 1, id;
        float cost;
        DataTable objdt = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lbban.Text = Request.QueryString["id"];
                gvMenu.Visible = true;
                LayDSOrder();
                LayDSOrdering();
                Gia();


                //GetDistinctValue();
            }
            if(Session["user"]==null)
                {
                    Response.Redirect("/DangNhap/DangNhap.aspx");
                }
                //DataList2.Visiable = false;
                //Response.Write("Đăng nhập thất bại");
            
        }


        //phong làm
       /* private void GetDistinctValue()
        {
            SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["con"].ToString());
            try
            {
                string query = "select *from MeNu2;";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                con.Open();
                da.Fill(objdt);
                con.Close();
                if(objdt.Rows.Count > 0)
                {
                    gvMenu.DataSource = objdt;
                    gvMenu.DataBind();
                 }  


            }
            catch
            {
                con.Close();
            }
        }*/

        private void LayDSOrder()
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = @"SELECT Id,Name, SoLuong, Gia,IdBan
                                FROM MeNu WHERE IdBan='" + lbban.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "DSBH");
            gvMenu.DataSource = ds.Tables["DSBH"];
            gvMenu.DataBind();
            con.Close();
        }
        private void LayDSOrdering()
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = @"SELECT Id,Name, SoLuong, Gia
                                FROM MeNu2";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "DSBH");
            GvOdering.DataSource = ds.Tables["DSBH"];
            GvOdering.DataBind();
            con.Close();
        }


        protected void btnHome0_Click(object sender, EventArgs e)
        {
            ListView1.Visible = true;
            ListView2.Visible = false;
            LvNuoc.Visible = false;
        }

        protected void btnMonThem_Click(object sender, EventArgs e)
        {
            ListView1.Visible = false;
            ListView2.Visible = true;
            LvNuoc.Visible = false;
        }

        protected void btnNuoc_Click(object sender, EventArgs e)
        {
            ListView1.Visible = false;
            ListView2.Visible = false;
            LvNuoc.Visible = true;
        }

        //Ham select
        private void Select(string query)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    read.Read();
                    if (read.HasRows)
                    {
                        id = int.Parse(read[0].ToString());
                        name = read[1].ToString();
                        cost = float.Parse(read[2].ToString());
                        //Thêm vào menu đang order
                        string sql = @"INSERT INTO MeNu2 VALUES(@fn, @slf, @gia)";
                        ThemMeNu(name, sl, cost, sql);
                        //LayDSOrder();
                        LayDSOrdering();
                        Gia();
                    }
                    con.Close();
                }
            }
        }


        //Ham them


        //Them Menu k co id
        private void ThemMeNu(string name, int sl, float gia, string query)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = query;
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@fn", name);
                cmd.Parameters.AddWithValue("@slf", sl);
                cmd.Parameters.AddWithValue("@gia", gia);
                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    lblThongBao.Visible = true;
                    //lblThongBao.Text = "Thêm thành công";

                }
                catch (Exception ex)
                {
                    lblThongBao.Visible = true;
                    lblThongBao.Text = "Đã tồn tại món";
                }
            }
        }



        //Xoa
        private int Xoa(int id, string sql)
        {
            int exe = 0;
            string query = sql;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    try
                    {
                        con.Open();
                        exe = (int)cmd.ExecuteNonQuery();
                        Gia();
                        lblThongBao.Visible = true;
                        lblThongBao.Text = "Thực hiện thành công";
                    }
                    catch (Exception ex)
                    {
                        lblThongBao.Visible = true;
                        lblThongBao.Text = "Thực hiện không thanh công";

                    }
                }
            }
            return exe;

        }

        protected void btnXoa_Click(object sender, EventArgs e)
        {
            string sql = "delete from MeNu where Id = @id ";
            int id = int.Parse((sender as Button).CommandArgument);
            int del = Xoa(id, sql);
            if (del > 0)
            {
                LayDSOrder();
            }
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            string id = Request.QueryString["id"];
            string pay = btnPay.Text;

            Response.Redirect("/thanhtoan/GDTT.aspx?id="+id+"&pay="+pay);
        }

        protected void ListView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int ma = int.Parse((sender as Button).CommandArgument);

            string query = @"SELECT * FROM MonAn
                WHERE Id ='" + ma + "' ";
            Select(query);
            gvMenu.Visible = false;
            GvOdering.Visible = true;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int ma = int.Parse((sender as Button).CommandArgument);
            string query = @"SELECT * FROM MonThem
                WHERE Id ='" + ma + "' ";
            Select(query);
            gvMenu.Visible = false;
            GvOdering.Visible = true;

        }

        protected void btnMonAn2_Click(object sender, EventArgs e)
        {
            int ma = int.Parse((sender as Button).CommandArgument);

            string query = @"SELECT * FROM MonAn
                WHERE Id ='" + ma + "' ";
            Select(query);
        }

        protected void btnNuoc_Click1(object sender, EventArgs e)
        {
            int ma = int.Parse((sender as Button).CommandArgument);

            string query = @"SELECT * FROM Nuoc
                WHERE Id ='" + ma + "' ";
            Select(query);
        }

        protected void btnNuoc2_Click(object sender, EventArgs e)
        {
            int ma = int.Parse((sender as Button).CommandArgument);

            string query = @"SELECT * FROM Nuoc
                WHERE Id ='" + ma + "' ";
            Select(query);
        }

        protected void btnXoa_Click1(object sender, EventArgs e)
        {
            string sql = "delete from MeNu";
            int del = Xoa(0, sql);
            if (del > 0)
            {
                LayDSOrder();
            }
        }

        protected void bntOdered_Click(object sender, EventArgs e)
        {
            gvMenu.Visible = true;
            LayDSOrder();
        }

        protected void btnOrdering_Click(object sender, EventArgs e)
        {
            GvOdering.Visible = true;
            LayDSOrdering();
        }

        protected void GvOdering_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //Xóa (-)
        protected void Button3_Click(object sender, EventArgs e)
        {
            id = int.Parse((sender as Button).CommandArgument);
            string sql = "delete from MeNu2 where Id = " + id + " ";
            //Lay so luong de dat dieu kien
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM MeNu2 WHERE Id = " + id + " ", con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    read.Read();
                    if (read.HasRows)
                    {
                        sl = int.Parse(read[2].ToString());
                        if (sl == 1)
                        {
                            int del = Xoa(id, sql);
                            if (del > 0)
                            {
                                LayDSOrdering();
                            }
                        }
                        else
                        {
                            //Neu so luong > 1 thi update so luong --
                            sl = sl - 1;
                            sql = @"UPDATE MeNu2 SET SoLuong = " + sl + " WHERE Id = " + id + "";
                            UpdateSL(sql);
                            LayDSOrdering();
                        }
                    }
                    con.Close();
                }
            }
        }

        protected void btnDone_Click(object sender, EventArgs e)
        {
            string sql;
            int del;
            using (SqlConnection con = new SqlConnection(connectionString))
            {

                using (SqlCommand cmd = new SqlCommand("SELECT * FROM MeNu2", con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    if (read.HasRows)
                    {
                        gvMenu.Visible = true;

                        while (read.Read())
                        {
                            id = int.Parse(read[0].ToString());
                            name = read[1].ToString();
                            sl = int.Parse(read[2].ToString());
                            cost = float.Parse(read[3].ToString());

                            sql = @"INSERT INTO MeNu VALUES(@fn, @slf, @gia,'" + lbban.Text + "')";
                            ThemMeNu(name, sl, cost, sql);
                        }
                        sql = "delete  from MeNu2  ";
                        del = Xoa(0, sql);
                        LayDSOrder();
                        LayDSOrdering();
                    }
                    con.Close();
                }
            }
        }

        //Ham sua va xoa so luong
        private void UpdateSL(string sql)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        lblThongBao.Visible = true;
                        lblThongBao.Text = "Sửa thành công";
                        LayDSOrdering();
                    }
                    catch (Exception ex)
                    {
                        lblThongBao.Visible = true;
                        lblThongBao.Text = ex.ToString();
                    }
                }
            }
        }
        //Nut so luong
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            id = int.Parse((sender as Button).CommandArgument);
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM MeNu2 WHERE Id = " + id + " ", con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    read.Read();
                    if (read.HasRows)
                    {
                        sl = int.Parse(read[2].ToString());
                        sl++;

                        string sql = @"UPDATE MeNu2 SET SoLuong = " + sl + " WHERE Id = " + id + "";
                        UpdateSL(sql);
                        con.Close();
                    }
                }
            }

        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("GDChinh.aspx?");
        }

        private void Gia()
        {
            string query = @"SELECT SUM(SoLuong*Gia) FROM MeNu WHERE IdBan='" + lbban.Text + "' ";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    read.Read();
                    if (read.HasRows)
                    {
                        btnPay.Text = read[0].ToString();
                    }

                    con.Close();
                }
            }
        }

        protected void gvMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void btnthanhtoan_Click(object sender, EventArgs e)
        {
            Response.Redirect("/ThanhToan/GDTT.aspx");
        }

    }
}