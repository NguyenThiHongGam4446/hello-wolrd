﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace QuanLyNhaHang.GiaoDienBan
{
    public partial class themmon : System.Web.UI.Page
    {

    string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["QLNH"].ConnectionString;
        string check = "True";
        protected void Page_Load(object sender, EventArgs e)
        {
           if(!IsPostBack)
            {
                LayDSMonAn();
                LayDSMonThem();
                LayDSNuoc();
                gvMonAn.Visible = false;
                gvMonThem.Visible = false;
                gvNuoc.Visible = false;
            }
            if(Session["user"]==null)
                {
                    Response.Redirect("/DangNhap/DangNhap.aspx");
                }
                //DataList2.Visible = false;
                //Response.Write("Dang nhap thanh cong");
            
        }

       
        private void LayDSMonAn()
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = @"SELECT MonAn.Name, MonAn.Cost
                                FROM MonAn";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "DSBH");
            gvMonAn.DataSource = ds.Tables["DSBH"];
            gvMonAn.DataBind();
            con.Close();
        }
        private void LayDSNuoc()
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = @"SELECT Nuoc.Name, Nuoc.Cost
                                FROM Nuoc";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "DSBH");
            gvNuoc.DataSource = ds.Tables["DSBH"];
            gvNuoc.DataBind();
            con.Close();
        }
        private void LayDSMonThem()
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = @"SELECT MonThem.Name, MonThem.Cost
                                FROM MonThem";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "DSBH");
            gvMonThem.DataSource = ds.Tables["DSBH"];
            gvMonThem.DataBind();
            con.Close();
        }

        //Hàm select
        private void Select(string query)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    read.Read();
                    if (read.HasRows)
                    {
                        txtName.Text = read[1].ToString();
                        txtGia.Text = read[2].ToString();
                    }
                    else
                    {
                        lblThongBao.Visible = true;
                        lblThongBao.Text = "No data";
                    }
                    con.Close();
                }
            }
        }
        protected void gvNuoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = gvNuoc.SelectedRow.Cells[0].Text;
            string query = @"SELECT * FROM Nuoc
                WHERE Name ='"+ name +"' OR Name like N'%"+ name +"%' ";
            Select(query);
            rdbMonAn.Checked = false;
            rdbNuocUong.Checked = true;
            rdbMonThem.Checked = false;
        }
        
        
        //Nut Theem
        protected void Button1_Click(object sender, EventArgs e)
        {
            if(rdbMonAn.Checked)
            {
                try
                {
                    string query = @"INSERT INTO MonAn VALUES(@name,@cost)";
                    string name = txtName.Text;
                    float cost = float.Parse(txtGia.Text);
                    Them(name, cost, query);
                    LayDSMonAn();
                    gvMonAn.Visible = true;
                    gvMonThem.Visible = false;
                    gvNuoc.Visible = false;
                }
                catch(Exception ex)
                {
                    lblThongBao.Visible = true;
                    lblThongBao.Text = "Giá phải là số nguyên";
                }
            }
            else if(rdbMonThem.Checked)
            {
                try
                {
                    string query = @"INSERT INTO MonThem VALUES(@name,@cost)";
                    string name = txtName.Text;
                    float cost = float.Parse(txtGia.Text);
                    Them(name, cost, query);
                    LayDSMonThem();
                    gvMonThem.Visible = true;
                    gvMonAn.Visible = false;
                    gvNuoc.Visible = false;
                }
                catch (Exception ex)
                {
                    lblThongBao.Visible = true;
                    lblThongBao.Text = "Giá phải là số nguyên";
                }
            }
            else if(rdbNuocUong.Checked)
            {
                try
                {
                    string query = @"INSERT INTO Nuoc VALUES(@name, @cost)";
                    string name = txtName.Text;
                    float cost = float.Parse(txtGia.Text);
                    Them(name, cost, query);
                    LayDSNuoc();
                    gvNuoc.Visible = true;
                    gvMonAn.Visible = false;
                    gvMonThem.Visible = false;
                }
                catch (Exception ex)
                {
                    lblThongBao.Visible = true;
                    lblThongBao.Text = "Giá phải là số nguyên";
                }
            }
            else
            {
                lblThongBao.Visible = true;
                lblThongBao.Text = "Bạn phải chọn 1 trong 3 ô trên";
            }
        }

        
        //Them 
        private void Them(string name, float cost, string query)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = query;
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@cost", cost);
                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    lblThongBao.Visible = true;
                    lblThongBao.Text = "Successfully";
                    
                }
                catch (Exception ex)
                {
                    lblThongBao.Visible = true;
                    lblThongBao.Text = "Đã tồn tại món";
                }
            }
        }


        protected void gvMonThem_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = gvMonThem.SelectedRow.Cells[0].Text;
            string query = @"SELECT * FROM MonThem
                WHERE Name ='" + name + "' OR Name like N'%" + name + "%' ";           
            Select(query);
            rdbMonAn.Checked = false;
            rdbNuocUong.Checked = false;
            rdbMonThem.Checked = true;
        }

        protected void rdbMonAn_CheckedChanged(object sender, EventArgs e)
        {
            
        }
        //Nut Xoa
        protected void btnXoa_Click(object sender, EventArgs e)
        {
            string sql = "delete from MonThem where Name = @name or Name like N'%@name%'";
            string name = (sender as Button).CommandArgument;
            int del = Xoa(name, sql);
            if(del > 0)
            {
                LayDSMonThem();
            }
        }

        //Xóa
        private int Xoa(string name, string sql)
        {
            int exe = 0;
            string query = sql;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    try
                    {
                        con.Open();
                        exe = (int)cmd.ExecuteNonQuery();
                        lblThongBao.Visible = true;
                        lblThongBao.Text = "Deleted successfully";
                    }catch(Exception ex)
                    {
                        lblThongBao.Visible = true;
                        lblThongBao.Text = ex.ToString();
                    }
                }
            }
            return exe;

        }

        protected void btnList_Click(object sender, EventArgs e)
        {
            gvMonAn.Visible = true;
            gvMonThem.Visible = true;
            gvNuoc.Visible = true;
            LayDSMonThem();
            LayDSNuoc();
            LayDSMonAn();
        }

        protected void btnXoaNuoc_Click(object sender, EventArgs e)
        {
            string sql = "delete from Nuoc where Name = @name or Name like N'%@name%'";
            string name = (sender as Button).CommandArgument;
            int del = Xoa(name, sql);
            if (del > 0)
            {
                LayDSNuoc();
            }
        }

        protected void btnXoaMonAn_Click(object sender, EventArgs e)
        {
            string sql = "delete from MonAn where Name = @name or Name like N'%@name%'";
            string name = (sender as Button).CommandArgument;
            int del = Xoa(name, sql);
            if (del > 0)
            {
                LayDSMonAn();
            }
        }

        protected void rdbNuocUong_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        protected void gvMonAn_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = gvMonAn.SelectedRow.Cells[0].Text;
            string query = @"SELECT * FROM MonAn
                WHERE Name ='" + name + "' OR Name like N'%" + name + "%' ";           
            Select(query);           
            rdbMonAn.Checked = true;
            rdbNuocUong.Checked = false;
            rdbMonThem.Checked = false;
        }
    }
}