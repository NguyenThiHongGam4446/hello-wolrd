﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QuanLyNhaHang.ThanhToan
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string sonhap;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack){

                txttongcong.Text = Request.QueryString["pay"];
                TextBox2.Text = Request.QueryString["pay"];
                
                TextBox3.Text = tienthoi().ToString() ;
            }
            if (Session["user"] == null)
            {
                Response.Redirect("/DangNhap/DangNhap.aspx");
            }
            
        }
        public double tienthoi()
        {
                string t1 = txttongcong.Text.ToString();
                string t2 = TextBox2.Text.ToString();
                 double tc = Double.Parse(t1);
                double kd = Double.Parse(t2);

            double tt = kd - tc;
            
            return tt;
            }

        protected void btnhuy_Click(object sender, EventArgs e)
        {
            string id = Request.QueryString["id"];
            string pay = Request.QueryString["pay"];
            Response.Redirect("/GiaoDienBan/Order.aspx?id="+id+"&pay="+pay);
        }

        protected void btnthanhtoan_Click(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            TextBox2.Text = "";
        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "1";
            TextBox2.Text = sonhap;
        }

        protected void btn2_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "2";
            TextBox2.Text = sonhap;
        }

        protected void btn3_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "3";
            TextBox2.Text = sonhap;
        }

        protected void btn4_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "4";
            TextBox2.Text = sonhap;
        }

        protected void btn5_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "5";
            TextBox2.Text = sonhap;
        }

        protected void btn6_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "6";
            TextBox2.Text = sonhap;
        }

        protected void btn7_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "7";
            TextBox2.Text = sonhap;
        }

        protected void btn8_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "8";
            TextBox2.Text = sonhap;
        }

        protected void btn9_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "9";
            TextBox2.Text = sonhap;
        }

        protected void btn0_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "0";
            TextBox2.Text = sonhap;
        }

        protected void btn000_Click(object sender, EventArgs e)
        {
            sonhap = TextBox2.Text + "000";
            TextBox2.Text = sonhap;
        }

        protected void btn20_Click(object sender, EventArgs e)
        {
            sonhap = "20000";
            TextBox2.Text = sonhap;
            TextBox3.Text = tienthoi().ToString();
        }

        protected void btn50_Click(object sender, EventArgs e)
        {
            sonhap = "50000";
            TextBox2.Text = sonhap;
            TextBox3.Text = tienthoi().ToString();
        }

        protected void btn100_Click(object sender, EventArgs e)
        {
            sonhap = "100000";
            TextBox2.Text = sonhap;
            TextBox3.Text = tienthoi().ToString();
        }

        protected void btn200_Click(object sender, EventArgs e)
        {
            sonhap = "200000";
            TextBox2.Text = sonhap;
            TextBox3.Text = tienthoi().ToString();
        }

        protected void btn500_Click(object sender, EventArgs e)
        {
            sonhap = "500000";
            TextBox2.Text = sonhap;
            TextBox3.Text = tienthoi().ToString();
        }
    }
}